package com.nwb.transfer.service;

import java.math.BigDecimal;

import com.nwb.transfer.exception.AccountNotExistException;
import com.nwb.transfer.exception.OverDraftException;
import com.nwb.transfer.exception.SystemException;
import com.nwb.transfer.model.Account;
import com.nwb.transfer.model.TransferRequest;

public interface AccountServiceInterface {
	public Account retrieveBalances(Long accountId);
	public void transferBalances(TransferRequest request) throws OverDraftException, AccountNotExistException, SystemException;
	public BigDecimal checkBalance(Long accountId) throws SystemException;
}
